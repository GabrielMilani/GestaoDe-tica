package br.com.gestaootica.dao;

import br.com.gestaootica.domain.Cliente;

public class ClienteDao extends GenericDao<Cliente>{

}
