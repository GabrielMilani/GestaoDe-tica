package br.com.gestaootica.dao;

import br.com.gestaootica.domain.Compra;

public class CompraDao extends GenericDao<Compra> {

}
