package br.com.gestaootica.dao;

import br.com.gestaootica.domain.OrdemServico;

public class OrdemServicoDao extends GenericDao<OrdemServico> {

}
