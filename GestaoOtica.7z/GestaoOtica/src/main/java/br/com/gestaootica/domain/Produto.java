package br.com.gestaootica.domain;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;

@SuppressWarnings("serial")
@Entity
public class Produto extends GenericDomain {
	
	@Column(length = 100, nullable = false)
	private String nomeProduto;
	
	@Column(length = 11, nullable = false)
	private int codInterno;
	
	@Column(nullable = false, precision = 6,scale = 2)
	private BigDecimal preco;
	
	@Column(nullable = false, precision = 6,scale = 2)
	private BigDecimal precoVenda;
	
	@Column(length = 11, nullable = false)
	private Short qtdeEstoque;

	//getters and setters
	
	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public int getCodInterno() {
		return codInterno;
	}

	public void setCodInterno(int codInterno) {
		this.codInterno = codInterno;
	}

	public BigDecimal getPreco() {
		return preco;
	}

	public void setPreco(BigDecimal preco) {
		this.preco = preco;
	}

	public BigDecimal getPrecoVenda() {
		return precoVenda;
	}

	public void setPrecoVenda(BigDecimal precoVenda) {
		this.precoVenda = precoVenda;
	}

	public Short getQtdeEstoque() {
		return qtdeEstoque;
	}

	public void setQtdeEstoque(Short qtdeEstoque) {
		this.qtdeEstoque = qtdeEstoque;
	}

	
	
}

