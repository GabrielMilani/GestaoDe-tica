package br.com.gestaootica.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@SuppressWarnings("serial")
@Entity
public class OrdemServico extends GenericDomain{
	
	
	@Column(nullable = false)
	@Temporal(TemporalType.DATE)
	private Date dataOS;

	@Column(length = 30, nullable = false)
	private String situacao;
	
	@Column(nullable = false, precision = 7, scale = 2)
	private BigDecimal formaPagamento;
	
	@ManyToOne
	@JoinColumn(nullable = false)
	private Cliente cliente;
	
	@ManyToOne
	@JoinColumn(nullable = false)
	private Funcionario funcionario;
	
	@JoinColumn(nullable = false)
	@ManyToOne
	private Produto produto;

	//getters and setters
	
	public Date getDataOS() {
		return dataOS;
	}

	public void setDataOS(Date dataOS) {
		this.dataOS = dataOS;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public BigDecimal getFormaPagamento() {
		return formaPagamento;
	}

	public void setFormaPagamento(BigDecimal formaPagamento) {
		this.formaPagamento = formaPagamento;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	public Produto getProduto() {
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}
	
		
	
}
