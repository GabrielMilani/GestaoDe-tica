package br.com.gestaootica.dao;

import br.com.gestaootica.domain.Produto;

public class ProdutoDao extends GenericDao<Produto> {

}
