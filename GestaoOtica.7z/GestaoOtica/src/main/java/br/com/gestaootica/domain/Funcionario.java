package br.com.gestaootica.domain;


import javax.persistence.Column;
import javax.persistence.Entity;

@SuppressWarnings("serial")
@Entity
public class Funcionario extends GenericDomain {

	@Column(length = 50, nullable = false)
	private String nome;
	
	@Column(length = 45, nullable = false)
	private String tipoFuncionario;
	
	@Column(length = 14, nullable = false)
	private String cpf;
	
	@Column(length = 30, nullable = false)
	private String cargo;
	
	@Column(length = 1, nullable = false)
	private int status;
	
	@Column(length = 20, nullable = false)
	private String login; 
	
	@Column(length = 10, nullable = false)
	private String senha;

	@Column(length = 100, nullable = false)
	private String endereco;

	//getters and setters
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipoFuncionario() {
		return tipoFuncionario;
	}

	public void setTipoFuncionario(String tipoFuncionario) {
		this.tipoFuncionario = tipoFuncionario;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
}
