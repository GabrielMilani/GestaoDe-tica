package br.com.gestaootica.dao;

import br.com.gestaootica.domain.Funcionario;

public class FuncionarioDao extends GenericDao<Funcionario> {

}
