package br.com.gestaootica.dao;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import br.com.gestaootica.domain.Funcionario;

public class FuncionarioDaoTest {

	@Ignore
	@Test
	public void salvar() {
		Funcionario funcionario = new Funcionario();
		//compra.setDataCompra();;
		//compra.setPreco(3,25L);;
		//compra.setProduto(produto);;
		funcionario.setCargo("Gerente");
		
		FuncionarioDao funcionarioDao = new FuncionarioDao();
		
		funcionarioDao.salvar(funcionario);
	}
	
	@Ignore
	@Test
	public void listar() {
		FuncionarioDao funcionarioDao = new FuncionarioDao();
			
		List<Funcionario> resultado = funcionarioDao.Listar();
		
		System.out.println("Total de Registros: "+ resultado.size());
		
		for (Funcionario funcionario : resultado) {
			System.out.println(funcionario.getCodigo());
			System.out.println(funcionario.getCpf());
			System.out.println(funcionario.getEndereco());
			System.out.println(funcionario.getCargo());
		}	
	}
	
	@Test
	@Ignore
	public void buscar() {
		Long codigo = 1L;
		FuncionarioDao funcionarioDao = new FuncionarioDao();
		Funcionario funcionario = funcionarioDao.buscar(codigo);
		
		if (funcionario == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			System.out.println(funcionario.getCodigo());
			System.out.println(funcionario.getCpf());
			System.out.println(funcionario.getEndereco());
			System.out.println(funcionario.getCargo());
		}		
	}
	
	@Test
	@Ignore
	public void excluir() {
		Long codigo = 1L;
		FuncionarioDao funcionarioDao = new FuncionarioDao();
		Funcionario funcionario = funcionarioDao.buscar(codigo);
		
		if (funcionario == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			funcionarioDao.excluir(funcionario);
			System.out.println("Registro Excluído");
		}
	}
	
	@Test
	@Ignore
	public void editar() {
		Long codigo = 1L;
		FuncionarioDao funcionarioDao = new FuncionarioDao();
		Funcionario funcionario = funcionarioDao.buscar(codigo);
		
		if (funcionario == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			funcionario.setCargo("Recepcionista");
			funcionarioDao.editar(funcionario);
			System.out.println(funcionario.getCodigo());
			System.out.println(funcionario.getCpf());
			System.out.println(funcionario.getEndereco());
			System.out.println(funcionario.getCargo());
		}
		
	}
	
	
}
