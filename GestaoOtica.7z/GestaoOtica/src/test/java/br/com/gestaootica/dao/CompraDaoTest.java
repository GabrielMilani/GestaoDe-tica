package br.com.gestaootica.dao;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;


import br.com.gestaootica.domain.Compra;

public class CompraDaoTest {
	
	@Ignore
	@Test
	public void salvar() {
		Compra compra = new Compra();
		//compra.setDataCompra();;
		//compra.setPreco(3,25L);;
		//compra.setProduto(produto);;
		compra.setQtde(1);
		
		CompraDao compraDao = new CompraDao();
		
		compraDao.salvar(compra);
	}
	
	@Ignore
	@Test
	public void listar() {
		CompraDao compraDao = new CompraDao();
			
		List<Compra> resultado = compraDao.Listar();
		
		System.out.println("Total de Registros: "+ resultado.size());
		
		for (Compra compra : resultado) {
			System.out.println(compra.getCodigo());
			System.out.println(compra.getDataCompra());
			System.out.println(compra.getPreco());
			System.out.println(compra.getProduto().getNomeProduto());
		}	
	}
	
	@Test
	@Ignore
	public void buscar() {
		Long codigo = 1L;
		CompraDao compraDao = new CompraDao();
		Compra compra = compraDao.buscar(codigo);
		
		if (compra == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			System.out.println(compra.getCodigo());
			System.out.println(compra.getDataCompra());
			System.out.println(compra.getPreco());
			System.out.println(compra.getProduto().getNomeProduto());
		}		
	}
	
	@Test
	@Ignore
	public void excluir() {
		Long codigo = 1L;
		CompraDao compraDao = new CompraDao();
			Compra compra = compraDao.buscar(codigo);
		
		if (compra == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			compraDao.excluir(compra);
			System.out.println("Registro Excluído");
		}
	}
	
	@Test
	@Ignore
	public void editar() {
		Long codigo = 3L;
		CompraDao compraDao = new CompraDao();
			Compra compra = compraDao.buscar(codigo);
		
		if (compra == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			compra.setQtde(3);
			compraDao.editar(compra);
			System.out.println(compra.getCodigo());
			System.out.println(compra.getDataCompra());
			System.out.println(compra.getPreco());
			System.out.println(compra.getProduto().getNomeProduto());
		}
		
	}
	

}
