package br.com.gestaootica.Util;

import org.hibernate.Session;
import org.junit.Test;

import br.com.gestaootica.util.HibernateUtil;

public class HibernateUtilTest {
	@Test
	public void conectar() {
		Session sessao = HibernateUtil.getFabricaSessoes().openSession();
		sessao.close();

	}
}
