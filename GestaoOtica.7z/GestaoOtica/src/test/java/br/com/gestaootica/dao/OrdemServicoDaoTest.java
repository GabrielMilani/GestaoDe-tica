package br.com.gestaootica.dao;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import br.com.gestaootica.domain.OrdemServico;;

public class OrdemServicoDaoTest {

	@Ignore
	@Test
	public void salvar() {
		OrdemServico ordemServico = new OrdemServico();
		//compra.setDataCompra());;
		//compra.setPreco(3,25L);;
		//compra.setProduto(produto);;
		ordemServico.setFormaPagamento(BigDecimal.valueOf(3.2));
		//ordemServico.setFormaPagamento(new BigDecimal(3.1));
		
		OrdemServicoDao ordemServicoDao = new OrdemServicoDao();
		
		ordemServicoDao.salvar(ordemServico);
	}
	
	@Ignore
	@Test
	public void listar() {
		OrdemServicoDao ordemServicoDao = new OrdemServicoDao();
			
		List<OrdemServico> resultado = ordemServicoDao.Listar();
		
		System.out.println("Total de Registros: "+ resultado.size());
		
		for (OrdemServico ordemServico : resultado) {
			System.out.println(ordemServico.getCodigo());
			System.out.println(ordemServico.getSituacao());
			System.out.println(ordemServico.getCliente().getNome());
			System.out.println(ordemServico.getFuncionario().getNome());
		}	
	}
	
	@Test
	@Ignore
	public void buscar() {
		Long codigo = 1L;
		OrdemServicoDao ordemServicoDao = new OrdemServicoDao();
		OrdemServico ordemServico = ordemServicoDao.buscar(codigo);
		
		if (ordemServico == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			System.out.println(ordemServico.getCodigo());
			System.out.println(ordemServico.getSituacao());
			System.out.println(ordemServico.getCliente().getNome());
			System.out.println(ordemServico.getFuncionario().getNome());
		}		
	}
	
	@Test
	@Ignore
	public void excluir() {
		Long codigo = 1L;
		OrdemServicoDao ordemServicoDao = new OrdemServicoDao();
		OrdemServico ordemServico = ordemServicoDao.buscar(codigo);
		
		if (ordemServico == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			ordemServicoDao.excluir(ordemServico);
			System.out.println("Registro Excluído");
		}
	}
	
	@Test
	@Ignore
	public void editar() {
		Long codigo = 1L;
		OrdemServicoDao ordemServicoDao = new OrdemServicoDao();
		OrdemServico ordemServico = ordemServicoDao.buscar(codigo);
		
		if (ordemServico == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			ordemServico.setFormaPagamento(BigDecimal.valueOf(3.8));
			ordemServicoDao.editar(ordemServico);
			System.out.println(ordemServico.getCodigo());
			System.out.println(ordemServico.getSituacao());
			System.out.println(ordemServico.getCliente().getNome());
			System.out.println(ordemServico.getFuncionario().getNome());
		}
		
	}
	
	
	
}
