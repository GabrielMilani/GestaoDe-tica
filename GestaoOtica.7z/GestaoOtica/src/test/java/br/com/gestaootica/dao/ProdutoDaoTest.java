package br.com.gestaootica.dao;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import br.com.gestaootica.domain.Produto;

public class ProdutoDaoTest {

	@Ignore
	@Test
	public void salvar() {
		Produto produto = new Produto();
		//compra.setDataCompra());;
		//compra.setPreco(3,25L);;
		//compra.setProduto(produto);;
		produto.setNomeProduto("Óculos de sol");
		ProdutoDao produtoDao = new ProdutoDao();
		
		produtoDao.salvar(produto);
	}
	
	@Ignore
	@Test
	public void listar() {
		ProdutoDao produtoDao = new ProdutoDao();
			
		List<Produto> resultado = produtoDao.Listar();
		
		System.out.println("Total de Registros: "+ resultado.size());
		
		for (Produto produto : resultado) {
			System.out.println(produto.getCodigo());
			System.out.println(produto.getNomeProduto());
			System.out.println(produto.getPreco());
			System.out.println(produto.getPrecoVenda());
			System.out.println(produto.getQtdeEstoque());
		}	
	}
	
	@Test
	@Ignore
	public void buscar() {
		Long codigo = 1L;
		ProdutoDao produtoDao = new ProdutoDao();
		Produto produto = produtoDao.buscar(codigo);
		
		if (produto == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			System.out.println(produto.getCodigo());
			System.out.println(produto.getNomeProduto());
			System.out.println(produto.getPreco());
			System.out.println(produto.getPrecoVenda());
			System.out.println(produto.getQtdeEstoque());
		}		
	}
	
	@Test
	@Ignore
	public void excluir() {
		Long codigo = 1L;
		ProdutoDao produtoDao = new ProdutoDao();
		Produto produto = produtoDao.buscar(codigo);
		
		if (produto == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			produtoDao.excluir(produto);
			System.out.println("Registro Excluído");
		}
	}
	
	@Test
	@Ignore
	public void editar() {
		Long codigo = 1L;
		ProdutoDao produtoDao = new ProdutoDao();
		Produto produto = produtoDao.buscar(codigo);
		
		if (produto == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			produto.setNomeProduto("Teste");
			produtoDao.editar(produto);
			System.out.println(produto.getCodigo());
			System.out.println(produto.getNomeProduto());
			System.out.println(produto.getPreco());
			System.out.println(produto.getPrecoVenda());
			System.out.println(produto.getQtdeEstoque());
		}
		
	}
	
	
	
	
}
