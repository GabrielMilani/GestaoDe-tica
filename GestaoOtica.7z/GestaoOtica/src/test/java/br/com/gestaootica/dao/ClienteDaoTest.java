package br.com.gestaootica.dao;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import br.com.gestaootica.domain.Cliente;


public class ClienteDaoTest {	
	
		
		/*ClienteDao estadoDao = new ClienteDao();
		Estado estado = estadoDao.buscar(1L);
		
		Cidade cidade = new Cidade();
		cidade.setNome("Ourinhos");
		cidade.setEstado(estado);
		
		CidadeDao cidadeDao = new CidadeDao();
		cidadeDao.salvar(cidade);
		*/

	@Ignore
	@Test
	public void salvar() {
		Cliente cliente = new Cliente();
		cliente.setCpf("02121212");
		//cliente.setDataNascimento(dataNascimento);
		cliente.setEmail("teste");
		cliente.setEstadoCivil("solteiro");
		cliente.setNacionalidade("Brasileira");
		cliente.setNaturalidade("Jacarezinhense");
		cliente.setNome("Luiz Henrique");
		cliente.setRg("02120122");
		cliente.setSexo('M');
		cliente.setStatus(1);
		cliente.setTelCelular("2152222");
		cliente.setTelResidencial("221645");
		cliente.setTipoCliente("fiel");
		
	}	
	
	@Test
	public void listar() {
		ClienteDao clienteDao = new ClienteDao();
			
		List<Cliente> resultado = clienteDao.Listar();
		
		System.out.println("Total de Registros: "+ resultado.size());
		
		for (Cliente cliente : resultado) {
			System.out.println(cliente.getCodigo());
			System.out.println(cliente.getCpf());
			System.out.println(cliente.getNome());
			System.out.println(cliente.getSexo());
			System.out.println(cliente.getTelResidencial());

		}	
	}
	
	@Test
	@Ignore
	public void buscar() {
		Long codigo = 1L;
		ClienteDao clienteDao = new ClienteDao();
		Cliente cliente = clienteDao.buscar(codigo);
		
		if (cliente == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
				System.out.println(cliente.getCodigo());
				System.out.println(cliente.getCpf());
				System.out.println(cliente.getNome());
				System.out.println(cliente.getSexo());
				System.out.println(cliente.getTelResidencial());
		}
	}
	
	@Test
	@Ignore
	public void excluir() {
		Long codigo = 1L;
		ClienteDao clienteDao = new ClienteDao();
		Cliente cliente = clienteDao.buscar(codigo);
		
		if (cliente == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			clienteDao.excluir(cliente);
			System.out.println("Registro Excluído");
		}
	}
	
	@Test
	@Ignore
	public void editar() {
		Long codigo = 3L;
		ClienteDao clienteDao = new ClienteDao();
			Cliente cliente = clienteDao.buscar(codigo);
		
		if (cliente == null) {
			System.out.println("Nenhum Registro Encontrado");
		}else {
			cliente.setRg("0002115454");
			clienteDao.editar(cliente);
			System.out.println(cliente.getCodigo());
			System.out.println(cliente.getCpf());
			System.out.println(cliente.getNome());
			System.out.println(cliente.getSexo());
			System.out.println(cliente.getTelResidencial());
		}
		
	}
	

}
